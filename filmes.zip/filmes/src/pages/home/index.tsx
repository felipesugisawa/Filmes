import React from 'react';
import Header from '../../components/header/index';

function Home() {
    return (
        <div >
            <Header/>
            <h1>Home</h1>
        </div>
    );
}

export default Home;