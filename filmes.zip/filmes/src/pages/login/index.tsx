import React from 'react';
import Header from '../../components/header/index'

function Login(){
    return(
        <div>
            <Header/>
            <h1>Login</h1>
        </div>
    )
}

export default Login;