import React from 'react';
import Header from '../../components/header/index';

function Cadastro(){
    return(
        <div>
            <Header/>
            <h1>Cadastro</h1>
        </div>
    )
}

export default Cadastro;